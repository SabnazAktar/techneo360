<footer class="footer">
                © 2022 - 2023 Employee Management <span class="d-none d-sm-inline-block"> - Crafted with <i class="mdi mdi-heart text-danger"></i> Sabnaz</span>.
            </footer>