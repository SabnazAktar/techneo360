@extends('layout.erp.home')
@section('page')

<a class='btn btn-success' href="{{route('roles.index')}}">Manage</a>
<table class='table'>
	<tr><th>Id</th><td>{{$role->id}}</td></tr>
	<tr><th>Name</th><td>{{$role->name}}</td></tr>

</table>

@endsection
