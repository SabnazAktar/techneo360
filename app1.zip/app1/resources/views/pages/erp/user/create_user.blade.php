@extends('layout.erp.home')
@section('page')

<a class='btn btn-success' href="{{url('/users')}}">Manage</a>
<form action="{{route('users.store')}}" method="post" enctype="multipart/form-data">
	@csrf
	{!! input_field(["label"=>"Name","name"=>"txtName"]) !!}
	{!! input_field(["label"=>"Password","name"=>"txtPassword"]) !!}
	{!! select_field(["label"=>"Role Id","name"=>"cmbRoleId","table"=>$roles]) !!}

	{!! input_button(["type"=>"submit","name"=>"btnCreate","value"=>"Create"]) !!}
</form>

@endsection
