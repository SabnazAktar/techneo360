@extends('layout.erp.home')
@section('page')

<a class='btn btn-success' href="{{route('users.index')}}">Manage</a>
<table class='table'>
	<tr><th>Id</th><td>{{$user->id}}</td></tr>
	<tr><th>Name</th><td>{{$user->name}}</td></tr>
	<tr><th>Password</th><td>{{$user->password}}</td></tr>
	<tr><th>Role Id</th><td>{{$user->role_id}}</td></tr>

</table>

@endsection
