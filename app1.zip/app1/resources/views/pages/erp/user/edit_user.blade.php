@extends('layout.erp.home')
@section('page')

<a class='btn btn-success' href="{{url('/users')}}">Manage</a>
<form action="{{route('users.update',$user)}}" method="post" enctype="multipart/form-data">
	@csrf
	@method("PUT")
	{!! input_field(["label"=>"Name","name"=>"txtName","value"=>$user->name]) !!}
	{!! input_field(["label"=>"Password","name"=>"txtPassword","value"=>$user->password]) !!}
	{!! select_field(["label"=>"Role Id","name"=>"cmbRoleId","table"=>$roles,"value"=>$user->role_id]) !!}

	{!! input_button(["type"=>"submit","name"=>"btnUpdate","value"=>"Update"]) !!}
</form>

@endsection
